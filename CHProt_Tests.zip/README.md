#**************************************************#
# Name : Binaires de tests
# Version : 1.0
# Auteurs : Jérôme Skoda, Joaquim Lefranc
#**************************************************#

MAKEFILE RULES :
----------------------------------------------------
 - make runserv : Execute le serveur
 - make runcli ip=0.0.0.0 : Execute le client, ip du serveur à spécifier
----------------------------------------------------